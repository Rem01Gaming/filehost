# Wait until boot completed
while [ -z "$(getprop sys.boot_completed)" ]; do
	sleep 40
done

# Remove old log
rm -f /data/adb/.config/encore_addon_bypasschg/bypasschg.log

# Start addon daemon
/data/adb/modules/encore_addon_bypasschg/bypasschg daemon
