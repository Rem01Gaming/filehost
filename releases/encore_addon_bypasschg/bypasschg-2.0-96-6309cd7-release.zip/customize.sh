# shellcheck disable=SC1091,SC2181
SKIPUNZIP=1

CONFIG_PATH="/data/adb/.config/encore_addon_bypasschg"
ENCORE_DIR="/data/adb/modules/encore"

make_dir() {
	[ ! -d "$1" ] && mkdir -p "$1"
}

abort_unsupported_arch() {
	ui_print "*********************************************************"
	ui_print "Unsupported Architecture: $ARCH"
	ui_print "Your CPU architecture is not supported by this addon."
	ui_print "If you believe this is an error, please report it to the maintainer."
	abort "*********************************************************"
}

abort_corrupted() {
	ui_print "*********************************************************"
	ui_print "Unable to extract verify.sh!"
	ui_print "Installation aborted. The module may be corrupted."
	ui_print "Please re-download and try again."
	abort "*********************************************************"
}

abort_old_encore() {
	ui_print "*********************************************************"
	ui_print "Encore Tweaks version is too old!"
	ui_print "Please install Encore Tweaks version 4.5 or newer."
	abort "*********************************************************"
}

abort_encore_not_installed() {
	ui_print "*********************************************************"
	ui_print "Encore Tweaks is not installed!"
	ui_print "Please install Encore Tweaks to use this module."
	abort "*********************************************************"
}

# EULA
ui_print "*********************************************************"
ui_print "By installing this module, you agree to the terms and conditions of the EULA."
ui_print "If you do not agree to the terms and conditions, do not install or use this module."
ui_print "Please read the EULA carefully before proceeding."
ui_print ""
ui_print "https://encore.rem01gaming.dev/legal/paid-addon-eula"
ui_print "*********************************************************"
ui_print ""
ui_print ""
sleep 3

# Check Encore Tweaks
if [ ! -d "$ENCORE_DIR" ] || [ -f "$ENCORE_DIR/disable" ] || [ -f "$ENCORE_DIR/remove" ]; then
	abort_encore_not_installed
fi

# Check Encore Version
encore_ver=$(grep -E '^versionCode=' "$ENCORE_DIR/module.prop" | cut -d'=' -f2)
[ "$encore_ver" -lt 975 ] && abort_old_encore

# Flashable integrity checkup
ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
[ ! -f "$TMPDIR/verify.sh" ] && abort_corrupted
source "$TMPDIR/verify.sh"

# Extract module files
ui_print "- Extracting module files"
extract "$ZIPFILE" 'module.prop' "$MODPATH"
extract "$ZIPFILE" 'service.sh' "$MODPATH"

# Target architecture
case $ARCH in
"arm64") ARCH_TMP="arm64-v8a" ;;
*) abort_unsupported_arch ;;
esac

# Extract executables
extract "$ZIPFILE" "libs/$ARCH_TMP/bypasschg" "$TMPDIR"
cp "$TMPDIR"/libs/"$ARCH_TMP"/* "$MODPATH"
rm -rf "$TMPDIR/libs"

# Set configs
ui_print "- Addon configuration setup"
make_dir "$CONFIG_PATH"
extract "$ZIPFILE" 'cacert.pem' "$CONFIG_PATH"

# Permission settings
ui_print "- Permission setup"
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755

# Start bypass charging and license test
ui_print "- Checking bypass charging support, this might take a while..."
ui_print ""

"$MODPATH/bypasschg" test_bypass 2>&1
[ $? -gt 0 ] && abort ""
"$MODPATH/bypasschg" test_license 2>&1
[ $? -gt 0 ] && abort ""
ui_print ""

# Easter Egg
case "$((RANDOM % 8 + 1))" in
1) ui_print "- Wooly's Fairy Tale" ;;
2) ui_print "- Sheep-counting Lullaby" ;;
3) ui_print "- Fog? The Black Shores!" ;;
4) ui_print "- Adventure? Let's go!" ;;
5) ui_print "- Hero Takes the Stage!" ;;
6) ui_print "- Woolies Save the World!" ;;
7) ui_print "- How much people will let you live for Encore?" ;;
8) ui_print "- Wen Donate?" ;;
esac
