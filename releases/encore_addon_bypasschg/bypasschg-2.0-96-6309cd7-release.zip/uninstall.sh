rm -rf /data/adb/.config/encore_addon_bypasschg
