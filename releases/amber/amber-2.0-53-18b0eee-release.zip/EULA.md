# END USER LICENSE AGREEMENT

**Encore Tweaks Paid Addon Modules**

Developer: Wisnu Gunawan (Rem01Gaming)

*Last updated: April 2026*

---

## Language / Bahasa

This Agreement is provided in both English and Indonesian. In the event of any conflict or inconsistency between the English version and the Indonesian version, the **Indonesian version** shall prevail.

Perjanjian ini disediakan dalam bahasa Inggris dan bahasa Indonesia. Apabila terdapat pertentangan atau ketidakkonsistenan antara versi bahasa Inggris dan versi bahasa Indonesia, maka yang berlaku adalah **versi bahasa Indonesia**.

---

# ENGLISH VERSION

---

## ⚠️ IMPORTANT — PLEASE READ BEFORE INSTALLING

This End User License Agreement ("Agreement") is a legally binding contract between you and the Developer. It governs your use of this module and contains important terms regarding liability, data collection, license revocation, and your legal rights.

**By installing or using this module, you agree to be bound by this Agreement.**
If you do not agree, do not install or use the module.

You will be asked to confirm that you have read this Agreement before downloading or activating the module. Please read it fully before proceeding.

---

## 1. Acceptance of Terms

By downloading, installing, activating, or otherwise using any paid module developed by Wisnu Gunawan (username: Rem01Gaming) (hereinafter "Developer"), you ("User") acknowledge that you have read, understood, and agree to be legally bound by this End User License Agreement ("Agreement"). If you do not agree to these terms, you must not install or use the module.

Prior to download or activation, the User will be presented with this Agreement and required to confirm having read it — either through a scroll-to-bottom mechanism, a checkbox acknowledgment, or a similar confirmation step on the Developer's distribution platform. Completion of this step constitutes explicit acceptance of this Agreement.

Where such a confirmation mechanism is unavailable or bypassed, installation or use of the module shall nonetheless constitute full acceptance of this Agreement. The User remains responsible for reading this Agreement regardless of the method by which it was accepted. The Developer makes this Agreement publicly available on the module's download page to ensure the User has a reasonable opportunity to review it at any time.

## 2. Eligibility and Age Restriction

The modules distributed by the Developer involve advanced Android modification techniques, including but not limited to root access, thermal throttling disabling, and charging behavior modification. These activities carry an inherent risk of permanent device damage ("bricking") during the rooting process or related procedures, which occur outside of the Developer's module and beyond the Developer's control.

Therefore, use of these modules is strictly limited to individuals who are 18 (eighteen) years of age or older. By accepting this Agreement, you represent and warrant that:

- You are at least 18 years of age; or
- If you are under 18, a parent or legal guardian has reviewed and accepted this Agreement on your behalf and accepts full responsibility for any and all risks and consequences.

The Developer reserves the right to revoke any license issued to a User found to be underage without refund.

## 3. License Grant

Subject to the terms and conditions of this Agreement, the Developer grants the User a limited, non-exclusive, non-transferable, revocable license to use the applicable module on a single authorized device ("Licensed Device").

The license is issued to a specific device, not to a person. Validity duration varies by license type, which may include:

- Permanent license — valid indefinitely unless revoked;
- Trial license — a time-limited free trial automatically granted to new users;
- Time-limited paid license — valid for a specified duration as set at the time of purchase.

Please refer to the module description page on the Developer's website for specific pricing and license duration information applicable to each module.

## 4. Device License Transfer

The User may transfer ("mutate") the license from one device to another subject to the following conditions:

- A license transfer may only be performed once every **sixty (60)** days, calculated from the date of the most recent transfer.
- Upon transfer, the license on the original (old) device is immediately and automatically revoked.
- A new license is issued to the replacement (new) device upon completion of the transfer process.
- The Developer bears no liability for any loss of access during or after a transfer.

Attempts to circumvent the transfer restriction (including but not limited to device spoofing or identifier manipulation) will be treated as a material breach of this Agreement and may result in permanent license revocation without refund.

## 5. Restrictions

The User shall NOT:

- Resell, sublicense, rent, lease, lend, or otherwise transfer the module or license to any third party;
- Reverse engineer, decompile, disassemble, or attempt to derive the source code of the module;
- Crack, patch, modify, or tamper with the module or any licensing mechanism;
- Remove or alter any copyright notices, license identifiers, or proprietary labels contained in the module;
- Use the module in any manner that violates applicable law.

Any violation of these restrictions constitutes a material breach of this Agreement and will result in immediate license revocation without refund, and may expose the User to civil and/or criminal liability.

## 6. License Revocation and Refund Policy

### 6.1 Revocation for Misconduct

The Developer reserves the right to revoke any license, without prior notice and without refund, if the User engages in conduct that the Developer reasonably deems harmful, abusive, or unlawful. Such conduct includes but is not limited to:

- Deliberately spreading false, defamatory, or misleading information about the Developer or the module;
- Attempting to frame, harass, or publicly damage the reputation of the Developer through dishonest means;
- Breaching any term or condition of this Agreement;
- Any other conduct the Developer reasonably considers a material breach of good faith or applicable law.

Revocation under this clause does not entitle the User to any refund or compensation.

### 6.2 Revocation Due to Product Issues

If a confirmed issue with the module renders it non-functional, the User may request a refund. Upon approval of a refund request, the associated license will be immediately revoked and the device will lose access to the module.

Refund eligibility is subject to the payment method used at the time of purchase:

- **Eligible for refund:** Payment methods that support transaction reversal (e.g., QRIS and similar methods where the Developer is technically able to process a return).
- **Not eligible for refund:** Payments made through donation-based platforms, including but not limited to Saweria, Sociabuzz, and Buymeacoffee. By choosing to pay through these platforms, the User expressly acknowledges that all funds transferred are voluntary donations, and that no refund can be issued regardless of circumstances — even if such platforms are the only payment method available to the User at the time of purchase.

The Developer will make reasonable efforts to assess refund requests in good faith, but reserves the right to determine whether a reported issue qualifies.

## 7. Disclaimer of Warranties

THE MODULE IS PROVIDED "AS IS" AND "AS AVAILABLE," WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, RELIABILITY, OR UNINTERRUPTED OPERATION.

The Developer does not warrant that the module will function correctly on any specific device. Android is an open platform with a wide range of non-standard implementations by Original Equipment Manufacturers (OEMs), and the Developer cannot guarantee compatibility with or reliable operation on all devices, firmware versions, or Android builds.

The User assumes all risk associated with the use of the module.

## 8. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW:

- The Developer shall not be liable for any indirect, incidental, consequential, special, or exemplary damages arising out of or in connection with this Agreement or the use of the module, including but not limited to: device damage, device bricking, data loss, voided manufacturer warranties, loss of profits, or any harm arising from the rooting process or any related procedure performed outside of the module itself.
- For claims directly arising from a defect or malfunction of the module itself, the Developer's total liability shall not exceed the amount actually paid by the User for the relevant module license.
- In all other cases, including claims involving exceptional or unforeseen circumstances, the Developer's total aggregate liability shall not exceed **IDR 1,500,000 (one million five hundred thousand Indonesian Rupiah)**, regardless of the nature or basis of the claim.

The User expressly acknowledges that the Developer has set prices and entered into this Agreement in reliance upon the limitations of liability set forth herein, and that such limitations form an essential basis of the bargain between the parties.
 
## 9. Privacy and Data Collection

### 9.1 Consent-Based Data Storage

No data is collected, transmitted, or stored on the Developer's systems automatically or without the User's explicit consent. The Developer's licensing system operates as follows:

- Upon first use, if the device has no existing record on the Developer's server, the module generates a **license token** locally on the User's device.
- The User may then voluntarily share this license token with the Developer to be registered on the server, enabling access to the module.
- Data is only stored on the Developer's server upon this explicit, User-initiated action.

The license token and associated registration may include the following device information:

- Device serial number (used as the primary license identifier);
- Hardware information (e.g., device model and chipset);
- Certain device identifiers (such as IMEI) indirectly — not directly fetched from the system, but may be present within sensitive partitions whose checksums are computed for identification purposes.

All data transmitted to the Developer's systems, with the exception of the device serial number, is processed using one-way cryptographic hashing prior to transmission. The raw values of these fields are never transmitted to the Developer's servers.

### 9.2 Program Activity Logs

Program activity logs remain stored locally on the User's device at all times and are never transmitted to the Developer automatically. Logs may be voluntarily shared by the User with the Developer solely for troubleshooting purposes, upon the Developer's request and the User's explicit consent.

### 9.3 Data Subject Rights

In accordance with applicable Indonesian law, including UU No. 27/2022 on Personal Data Protection, the User has the following rights regarding their data stored on the Developer's systems:

- **Right to Access:** The User may request a copy of the data associated with their licensed device at any time by contacting the Developer.
- **Right to Deletion:** The User may request permanent deletion of their data from the Developer's systems. The User acknowledges that exercising this right will result in immediate and permanent revocation of the associated license, with no refund provided. The User may subsequently request reinstatement of their license, which will require re-submitting their license token and re-registering their device as a new record.

### 9.4 Data Sharing

The Developer does not sell, trade, or otherwise transfer User data to third parties, except as required by applicable law or legal process.

### 9.5 Data Breach Notification

In the event of a data breach or unauthorized access to the Developer's systems that affects User data, the Developer will make reasonable good-faith efforts to notify affected Users through official channels (including the Developer's Telegram channel or other social media platforms) as soon as reasonably practicable, and in accordance with obligations under applicable Indonesian law.

### 9.6 Data Retention

To maintain the integrity of the licensing system and prevent abuse, device license records (including hashed identifiers) are retained indefinitely on the Developer's systems, even after a license is revoked or terminated, unless the User explicitly exercises their Right to Deletion under Section 9.3.

## 10. Termination

This Agreement is effective until terminated. Upon termination, whether by the Developer's revocation or otherwise:

- The User's license is immediately revoked and access to the module is disabled;
- No refund, compensation, or substitute access will be provided, except as set out in Section 6.2;
- License data will be deactivated in active systems; see Section 9 regarding data retention practices;
- The User may be subject to legal action if the termination was the result of a breach of this Agreement or other unlawful conduct.

Sections 5, 7, 8, 9, 11, and 12 of this Agreement shall survive any termination.

## 11. Intellectual Property

The module, including all source code, object code, documentation, design, logic, and related materials, is the exclusive intellectual property of Wisnu Gunawan (Rem01Gaming). All rights are reserved.

This Agreement does not grant the User any ownership rights, title, or interest in the module. The User receives only the limited license rights expressly set forth in Section 3 of this Agreement.

Any unauthorized reproduction, distribution, or creation of derivative works is strictly prohibited and may constitute infringement under applicable intellectual property laws.

## 12. Governing Law and Jurisdiction

This Agreement shall be governed by and construed in accordance with the laws of the Republic of Indonesia, without regard to its conflict of law principles.

Any dispute, claim, or controversy arising out of or relating to this Agreement, or the breach, termination, or validity thereof, shall first be attempted to be resolved through good-faith negotiation between the parties. If the parties are unable to resolve the dispute through negotiation within thirty (30) days, the dispute shall be submitted to the exclusive jurisdiction of the **Pengadilan Negeri Semarang** (Semarang District Court), Republic of Indonesia.

## 13. Severability

If any provision of this Agreement is held by a court of competent jurisdiction to be invalid, illegal, or unenforceable, that provision shall be modified to the minimum extent necessary to make it enforceable, or, if such modification is not possible, it shall be severed from this Agreement. The remaining provisions of this Agreement shall continue in full force and effect.

## 14. Entire Agreement

This Agreement constitutes the entire agreement between the Developer and the User with respect to the subject matter hereof and supersedes all prior or contemporaneous communications, representations, or agreements, whether written or oral, including any statements made by the Developer or their representatives on any platform (including but not limited to Telegram, Discord, or social media).

## 15. Updates to This Agreement

The Developer reserves the right to modify or update this Agreement at any time. In the event of any material change, the Developer will make reasonable good-faith efforts to notify Users through official channels (including but not limited to the Developer's Telegram channel or other social media platforms), though such notification cannot be guaranteed in all circumstances.

Any changes will take effect **7 (seven) days** after being made available by the Developer, unless the change is required immediately by applicable law or to address urgent security or abuse concerns, in which case it may take effect sooner.

Your continued use of the module after the effective date of any modification constitutes your acceptance of the updated Agreement. It is the User's responsibility to review this Agreement periodically. If you do not agree to the updated terms, you must discontinue use of the module before the change takes effect.

## 16. Contact Information

For legal notices, licensing inquiries, or any questions regarding this Agreement, the User may contact the Developer through the following channels:

- Telegram: @Rem01Gaming
- Email: Rem01_Gaming@proton.me

The Developer will make reasonable efforts to respond to inquiries but does not guarantee a response within any specific timeframe.

*By installing or using the module, you confirm that you have read, understood, and agreed to this Agreement.*

Copyright (c) 2026 Wisnu Gunawan (Rem01Gaming). All Rights Reserved.

---

# VERSI BAHASA INDONESIA

---

## ⚠️ PENTING — HARAP DIBACA SEBELUM MEMASANG

Perjanjian Lisensi Pengguna Akhir ini ("Perjanjian") adalah kontrak yang mengikat secara hukum antara Anda dan Pengembang. Perjanjian ini mengatur penggunaan modul ini dan memuat ketentuan penting mengenai tanggung jawab, pengumpulan data, pencabutan lisensi, dan hak hukum Anda.

**Dengan memasang atau menggunakan modul ini, Anda setuju untuk terikat oleh Perjanjian ini.**
Jika Anda tidak setuju, jangan pasang atau gunakan modul ini.

Anda akan diminta untuk mengonfirmasi bahwa Anda telah membaca Perjanjian ini sebelum mengunduh atau mengaktifkan modul. Harap baca seluruhnya sebelum melanjutkan.

---

## 1. Penerimaan Ketentuan

Dengan mengunduh, memasang, mengaktifkan, atau menggunakan modul berbayar yang dikembangkan oleh Wisnu Gunawan (nama pengguna: Rem01Gaming) (selanjutnya disebut "Pengembang"), Anda ("Pengguna") mengakui bahwa Anda telah membaca, memahami, dan menyetujui untuk terikat secara hukum oleh Perjanjian Lisensi Pengguna Akhir ini ("Perjanjian"). Jika Anda tidak menyetujui ketentuan ini, Anda tidak boleh memasang atau menggunakan modul tersebut.

Sebelum mengunduh atau mengaktifkan modul, Pengguna akan disajikan dengan Perjanjian ini dan diminta untuk mengonfirmasi telah membacanya — baik melalui mekanisme gulir hingga bawah, tanda centang persetujuan, atau langkah konfirmasi serupa pada platform distribusi Pengembang. Penyelesaian langkah ini merupakan penerimaan eksplisit atas Perjanjian ini.

Apabila mekanisme konfirmasi tersebut tidak tersedia atau dilewati, pemasangan atau penggunaan modul tetap merupakan penerimaan penuh atas Perjanjian ini. Pengguna tetap bertanggung jawab untuk membaca Perjanjian ini terlepas dari metode penerimaannya. Pengembang menyediakan Perjanjian ini secara publik di halaman unduhan modul untuk memastikan Pengguna memiliki kesempatan yang wajar untuk meninjaunya kapan saja.

## 2. Kelayakan dan Batasan Usia

Modul yang didistribusikan oleh Pengembang melibatkan teknik modifikasi Android tingkat lanjut, termasuk namun tidak terbatas pada akses root, penonaktifan pembatasan termal, dan modifikasi perilaku pengisian daya. Aktivitas ini mengandung risiko bawaan kerusakan permanen perangkat ("bricking") selama proses rooting atau prosedur terkait, yang terjadi di luar modul Pengembang dan di luar kendali Pengembang.

Oleh karena itu, penggunaan modul ini secara ketat terbatas pada individu yang berusia 18 (delapan belas) tahun atau lebih. Dengan menerima Perjanjian ini, Anda menyatakan dan menjamin bahwa:

- Anda setidaknya berusia 18 tahun; atau
- Jika Anda berusia di bawah 18 tahun, orang tua atau wali sah telah meninjau dan menerima Perjanjian ini atas nama Anda dan menerima tanggung jawab penuh atas segala risiko dan konsekuensi.

Pengembang berhak untuk mencabut lisensi yang diberikan kepada Pengguna yang terbukti di bawah umur tanpa pengembalian dana.

## 3. Pemberian Lisensi

Dengan tunduk pada syarat dan ketentuan Perjanjian ini, Pengembang memberikan kepada Pengguna lisensi terbatas, non-eksklusif, tidak dapat dialihkan, dan dapat dicabut untuk menggunakan modul yang berlaku pada satu perangkat yang sah ("Perangkat Berlisensi").

Lisensi diberikan kepada perangkat tertentu, bukan kepada orang. Durasi berlaku bervariasi menurut jenis lisensi, yang dapat mencakup:

- Lisensi permanen — berlaku tanpa batas waktu kecuali dicabut;
- Lisensi uji coba — uji coba gratis terbatas waktu yang secara otomatis diberikan kepada pengguna baru;
- Lisensi berbayar terbatas waktu — berlaku untuk durasi tertentu sebagaimana ditetapkan pada saat pembelian.

Silakan merujuk ke halaman deskripsi modul di situs web Pengembang untuk informasi harga spesifik dan durasi lisensi yang berlaku untuk setiap modul.

## 4. Pengalihan Lisensi Antar Perangkat

Pengguna dapat mengalihkan ("mutasi") lisensi dari satu perangkat ke perangkat lain dengan ketentuan sebagai berikut:

- Pengalihan lisensi hanya dapat dilakukan sekali setiap **enam puluh (60)** hari, dihitung dari tanggal pengalihan terakhir.
- Setelah pengalihan, lisensi pada perangkat asli (lama) segera dan otomatis dicabut.
- Lisensi baru diterbitkan untuk perangkat pengganti (baru) setelah proses pengalihan selesai.
- Pengembang tidak bertanggung jawab atas kehilangan akses selama atau setelah pengalihan.

Upaya untuk menghindari batasan pengalihan (termasuk namun tidak terbatas pada spoofing perangkat atau manipulasi pengenal) akan dianggap sebagai pelanggaran material atas Perjanjian ini dan dapat mengakibatkan pencabutan lisensi permanen tanpa pengembalian dana.

## 5. Larangan

Pengguna DILARANG:

- Menjual kembali, memberikan sublisensi, menyewakan, membiayai sewa, meminjamkan, atau mengalihkan modul atau lisensi kepada pihak ketiga mana pun;
- Melakukan rekayasa balik, dekompilasi, disasembling, atau mencoba memperoleh kode sumber modul;
- Melakukan crack, patch, modifikasi, atau merusak mekanisme lisensi apa pun;
- Menghapus atau mengubah pemberitahuan hak cipta, pengenal lisensi, atau label kepemilikan yang terkandung dalam modul;
- Menggunakan modul dengan cara apa pun yang melanggar hukum yang berlaku.

Setiap pelanggaran terhadap larangan ini merupakan pelanggaran material atas Perjanjian ini dan akan mengakibatkan pencabutan lisensi segera tanpa pengembalian dana, serta dapat membuat Pengguna terkena tanggung jawab perdata dan/atau pidana.

## 6. Pencabutan Lisensi dan Kebijakan Pengembalian Dana

### 6.1 Pencabutan karena Pelanggaran

Pengembang berhak mencabut lisensi mana pun, tanpa pemberitahuan sebelumnya dan tanpa pengembalian dana, apabila Pengguna terlibat dalam tindakan yang dianggap merugikan, menyalahgunakan, atau melanggar hukum oleh Pengembang. Tindakan tersebut mencakup namun tidak terbatas pada:

- Dengan sengaja menyebarkan informasi palsu, fitnah, atau menyesatkan mengenai Pengembang atau modul;
- Mencoba memfitnah, melecehkan, atau merusak reputasi Pengembang secara tidak jujur di ruang publik;
- Melanggar ketentuan atau syarat apa pun dalam Perjanjian ini;
- Tindakan lain yang secara wajar dianggap Pengembang sebagai pelanggaran material atas itikad baik atau hukum yang berlaku.

Pencabutan berdasarkan klausul ini tidak memberikan hak kepada Pengguna atas pengembalian dana atau kompensasi apa pun.

### 6.2 Pencabutan karena Masalah Produk

Apabila terdapat masalah yang terkonfirmasi pada modul sehingga menyebabkan modul tidak dapat berfungsi, Pengguna dapat mengajukan permintaan pengembalian dana. Setelah permintaan pengembalian dana disetujui, lisensi yang terkait akan segera dicabut dan perangkat akan kehilangan akses ke modul.

Kelayakan pengembalian dana bergantung pada metode pembayaran yang digunakan pada saat pembelian:

- **Berhak mendapatkan pengembalian dana:** Metode pembayaran yang mendukung pembalikan transaksi (misalnya QRIS dan metode serupa di mana Pengembang secara teknis mampu memproses pengembalian).
- **Tidak berhak mendapatkan pengembalian dana:** Pembayaran yang dilakukan melalui platform berbasis donasi, termasuk namun tidak terbatas pada Saweria, Sociabuzz, dan Buymeacoffee. Dengan memilih untuk membayar melalui platform-platform ini, Pengguna secara tegas mengakui bahwa semua dana yang ditransfer merupakan donasi sukarela, dan bahwa tidak ada pengembalian dana yang dapat diberikan dalam keadaan apa pun — bahkan jika platform tersebut merupakan satu-satunya metode pembayaran yang tersedia bagi Pengguna pada saat pembelian.

Pengembang akan berupaya dengan itikad baik untuk menilai permintaan pengembalian dana secara wajar, namun berhak menentukan apakah masalah yang dilaporkan memenuhi syarat untuk mendapatkan pengembalian dana.

## 7. Penyangkalan Jaminan

MODUL DISEDIAKAN "SEBAGAIMANA ADANYA" DAN "SESUAI KETERSEDIAAN," TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN TERSIRAT, TERMASUK NAMUN TIDAK TERBATAS PADA JAMINAN KELAYAKAN JUAL, KESESUAIAN UNTUK TUJUAN TERTENTU, TIDAK MELANGGAR HAK PIHAK LAIN, KEANDALAN, ATAU OPERASI TANPA GANGGUAN.

Pengembang tidak menjamin bahwa modul akan berfungsi dengan benar pada perangkat tertentu. Android adalah platform terbuka dengan berbagai macam implementasi non-standar oleh Produsen Peralatan Asli (OEM), dan Pengembang tidak dapat menjamin kompatibilitas dengan atau pengoperasian yang andal pada semua perangkat, versi firmware, atau bentukan Android.

Pengguna menanggung semua risiko yang terkait dengan penggunaan modul.

## 8. Batasan Tanggung Jawab

SEJAUH MAKSIMAL YANG DIIZINKAN OLEH HUKUM YANG BERLAKU:

- Pengembang tidak bertanggung jawab atas kerugian tidak langsung, insidental, konsekuensial, khusus, atau contoh yang timbul dari atau sehubungan dengan Perjanjian ini atau penggunaan modul, termasuk namun tidak terbatas pada: kerusakan perangkat, kerusakan permanen perangkat ("brick"), kehilangan data, batalnya garansi pabrikan, kehilangan keuntungan, atau kerugian apa pun yang timbul dari proses rooting atau prosedur terkait yang dilakukan di luar modul itu sendiri.
- Untuk klaim yang timbul langsung dari cacat atau kerusakan fungsi modul itu sendiri, total tanggung jawab Pengembang tidak melebihi jumlah yang sebenarnya dibayarkan oleh Pengguna untuk lisensi modul yang bersangkutan.
- Dalam semua kasus lainnya, termasuk klaim yang melibatkan keadaan luar biasa atau tak terduga, total tanggung jawab agregat Pengembang tidak melebihi **IDR 1.500.000 (satu juta lima ratus ribu Rupiah Indonesia)**, terlepas dari sifat atau dasar klaim tersebut.

Pengguna dengan tegas mengakui bahwa Pengembang telah menetapkan harga dan memasuki Perjanjian ini berdasarkan pembatasan tanggung jawab yang diatur di sini, dan bahwa pembatasan tersebut merupakan dasar penting dari kesepakatan antara para pihak.

## 9. Privasi dan Pengumpulan Data

### 9.1 Penyimpanan Data Berdasarkan Persetujuan

Tidak ada data yang dikumpulkan, dikirimkan, atau disimpan di sistem Pengembang secara otomatis atau tanpa persetujuan eksplisit Pengguna. Sistem lisensi Pengembang beroperasi sebagai berikut:

- Pada penggunaan pertama, jika perangkat tidak memiliki catatan yang ada di server Pengembang, modul akan menghasilkan **token lisensi** secara lokal di perangkat Pengguna.
- Pengguna kemudian dapat secara sukarela membagikan token lisensi ini kepada Pengembang untuk didaftarkan di server, sehingga memungkinkan akses ke modul.
- Data hanya disimpan di server Pengembang setelah tindakan yang diprakarsai secara eksplisit oleh Pengguna ini.

Token lisensi dan pendaftaran terkait dapat mencakup informasi perangkat berikut:

- Nomor seri perangkat (digunakan sebagai pengenal lisensi utama);
- Informasi perangkat keras (misalnya, model perangkat dan chipset);
- Pengenal perangkat tertentu (seperti IMEI) secara tidak langsung — tidak diambil langsung dari sistem, tetapi mungkin ada di dalam partisi sensitif yang checksum-nya dibuat untuk tujuan identifikasi.

Semua data yang dikirimkan ke sistem Pengembang, dengan pengecualian nomor seri perangkat, diproses menggunakan hashing kriptografis satu arah sebelum transmisi. Nilai mentah dari data-data ini tidak pernah dikirimkan ke server Pengembang.

### 9.2 Log Aktivitas Program

Log aktivitas program tetap tersimpan secara lokal di perangkat Pengguna setiap saat dan tidak pernah dikirimkan secara otomatis kepada Pengembang. Log dapat dibagikan secara sukarela oleh Pengguna kepada Pengembang semata-mata untuk tujuan pemecahan masalah, atas permintaan Pengembang dan persetujuan eksplisit Pengguna.

### 9.3 Hak Subjek Data

Sesuai dengan hukum Indonesia yang berlaku, termasuk UU No. 27/2022 tentang Perlindungan Data Pribadi, Pengguna memiliki hak-hak berikut atas data mereka yang tersimpan di sistem Pengembang:

- **Hak Akses:** Pengguna dapat meminta salinan data yang terkait dengan perangkat berlisensi mereka kapan saja dengan menghubungi Pengembang.
- **Hak Penghapusan:** Pengguna dapat meminta penghapusan permanen data mereka dari sistem Pengembang. Pengguna mengakui bahwa penggunaan hak ini akan mengakibatkan pencabutan lisensi yang terkait secara segera dan permanen, tanpa pengembalian dana. Pengguna kemudian dapat meminta pemulihan lisensi mereka, yang akan memerlukan pengiriman ulang token lisensi dan pendaftaran ulang perangkat mereka sebagai catatan baru.

### 9.4 Berbagi Data

Pengembang tidak menjual, memperdagangkan, atau mengalihkan data Pengguna kepada pihak ketiga, kecuali jika diwajibkan oleh hukum yang berlaku atau proses hukum.

### 9.5 Pemberitahuan Pelanggaran Data

Dalam hal terjadi pelanggaran data atau akses tidak sah ke sistem Pengembang yang memengaruhi data Pengguna, Pengembang akan melakukan upaya yang wajar dengan itikad baik untuk memberi tahu Pengguna yang terdampak melalui saluran resmi (termasuk saluran Telegram atau platform media sosial lainnya milik Pengembang) sesegera mungkin, dan sesuai dengan kewajiban berdasarkan hukum Indonesia yang berlaku.

### 9.6 Retensi Data

Untuk menjaga integritas sistem lisensi dan mencegah penyalahgunaan, catatan lisensi perangkat (termasuk pengenal yang telah di-hash) disimpan tanpa batas waktu di sistem Pengembang, bahkan setelah lisensi dicabut atau dihentikan, kecuali jika Pengguna secara eksplisit menggunakan Hak Penghapusan mereka berdasarkan Bagian 9.3.

## 10. Penghentian

Perjanjian ini berlaku sampai dihentikan. Setelah penghentian, baik karena pencabutan oleh Pengembang atau sebaliknya:

- Lisensi Pengguna segera dicabut dan akses ke modul dinonaktifkan;
- Tidak akan ada pengembalian dana, kompensasi, atau akses pengganti yang diberikan, kecuali sebagaimana diatur dalam Bagian 6.2;
- Data lisensi akan dinonaktifkan dalam sistem aktif; lihat Bagian 9 mengenai praktik retensi data;
- Pengguna dapat dikenai tindakan hukum jika penghentian tersebut disebabkan oleh pelanggaran Perjanjian ini atau perilaku melawan hukum lainnya.

Bagian 5, 7, 8, 9, 11, dan 12 dari Perjanjian ini akan tetap berlaku setelah penghentian apa pun.

## 11. Kekayaan Intelektual

Modul, termasuk semua kode sumber, kode objek, dokumentasi, desain, logika, dan materi terkait, adalah kekayaan intelektual eksklusif Wisnu Gunawan (Rem01Gaming). Seluruh hak dilindungi.

Perjanjian ini tidak memberikan hak kepemilikan, gelar, atau kepentingan apa pun kepada Pengguna atas modul tersebut. Pengguna hanya menerima hak lisensi terbatas yang secara tegas diatur dalam Bagian 3 Perjanjian ini.

Setiap reproduksi, distribusi, atau pembuatan karya turunan yang tidak sah sangat dilarang dan dapat merupakan pelanggaran berdasarkan hukum kekayaan intelektual yang berlaku.

## 12. Hukum yang Mengatur dan Yurisdiksi

Perjanjian ini akan diatur dan ditafsirkan sesuai dengan hukum Republik Indonesia, tanpa memperhatikan asas konflik hukum.

Setiap sengketa, klaim, atau kontroversi yang timbul dari atau terkait dengan Perjanjian ini, atau pelanggaran, penghentian, atau keabsahannya, pertama-tama akan diupayakan untuk diselesaikan melalui negosiasi dengan itikad baik antara para pihak. Jika para pihak tidak dapat menyelesaikan sengketa melalui negosiasi dalam waktu tiga puluh (30) hari, sengketa tersebut akan diajukan ke yurisdiksi eksklusif **Pengadilan Negeri Semarang**, Republik Indonesia.

## 13. Dapat Dipisahkannya Ketentuan

Jika suatu ketentuan dalam Perjanjian ini dinyatakan tidak sah, ilegal, atau tidak dapat dilaksanakan oleh pengadilan yang berwenang, ketentuan tersebut akan dimodifikasi seminimal mungkin agar dapat dilaksanakan, atau jika modifikasi tersebut tidak memungkinkan, ketentuan tersebut akan dipisahkan dari Perjanjian ini. Ketentuan lainnya yang tersisa dalam Perjanjian ini akan tetap berlaku penuh.

## 14. Keseluruhan Perjanjian

Perjanjian ini merupakan keseluruhan perjanjian antara Pengembang dan Pengguna sehubungan dengan subjek yang diatur di sini dan menggantikan semua komunikasi, pernyataan, atau perjanjian sebelumnya atau yang sezaman, baik tertulis maupun lisan, termasuk pernyataan apa pun yang dibuat oleh Pengembang atau perwakilannya di platform apa pun (termasuk namun tidak terbatas pada Telegram, Discord, atau media sosial).

## 15. Pembaruan Perjanjian Ini

Pengembang berhak untuk memodifikasi atau memperbarui Perjanjian ini kapan saja. Dalam hal terdapat perubahan yang material, Pengembang akan melakukan upaya yang wajar dengan itikad baik untuk memberi tahu Pengguna melalui saluran resmi (termasuk namun tidak terbatas pada saluran Telegram atau platform media sosial lainnya milik Pengembang), meskipun pemberitahuan tersebut tidak dapat dijamin dalam semua keadaan.

Setiap perubahan akan berlaku **7 (tujuh) hari** setelah tersedia oleh Pengembang, kecuali perubahan tersebut segera diperlukan oleh hukum yang berlaku atau untuk menangani masalah keamanan atau penyalahgunaan yang mendesak, yang dalam hal ini dapat berlaku lebih cepat.

Penggunaan modul Anda yang berkelanjutan setelah tanggal berlakunya modifikasi apa pun merupakan penerimaan Anda terhadap Perjanjian yang diperbarui. Tanggung jawab Pengguna untuk meninjau Perjanjian ini secara berkala. Jika Anda tidak menyetujui ketentuan yang diperbarui, Anda harus menghentikan penggunaan modul sebelum perubahan berlaku.

## 16. Informasi Kontak

Untuk pemberitahuan hukum, pertanyaan lisensi, atau pertanyaan apa pun mengenai Perjanjian ini, Pengguna dapat menghubungi Pengembang melalui saluran berikut:

- Telegram: @Rem01Gaming
- Email: Rem01_Gaming@proton.me

Pengembang akan melakukan upaya yang wajar untuk menanggapi pertanyaan tetapi tidak menjamin respons dalam jangka waktu tertentu.

*Dengan memasang atau menggunakan modul, Anda mengonfirmasi bahwa Anda telah membaca, memahami, dan menyetujui Perjanjian ini.*

Copyright (c) 2026 Wisnu Gunawan (Rem01Gaming). Hak Cipta Dilindungi Undang-Undang.
