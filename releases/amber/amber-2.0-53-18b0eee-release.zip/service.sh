# Wait until boot completed
while [ -z "$(getprop sys.boot_completed)" ]; do
	sleep 40
done

# Clear old logs
rm -rf /data/adb/.config/amber/amber.log

# Start addon daemon
/data/adb/modules/amber/amber daemon
