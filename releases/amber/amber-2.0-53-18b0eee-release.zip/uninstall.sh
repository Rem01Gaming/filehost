rm -rf /data/adb/.config/amber
